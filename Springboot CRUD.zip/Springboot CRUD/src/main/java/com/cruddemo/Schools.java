package com.cruddemo;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Schools {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String schoolName;
    private String schoolEmail;

    // Default constructor
    public Schools() {
    }

    // Parameterized constructor
    public Schools(Long id, String schoolName, String schoolEmail) {
        this.id = id;
        this.schoolName = schoolName;
        this.schoolEmail = schoolEmail;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSchoolName() {
        return schoolName;
    }

    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }

    public String getSchoolEmail() {
        return schoolEmail;
    }

    public void setSchoolEmail(String schoolEmail) {
        this.schoolEmail = schoolEmail;
    }

    @Override
    public String toString() {
        return "Schools{" +
                "id=" + id +
                ", schoolName='" + schoolName + '\'' +
                ", schoolEmail='" + schoolEmail + '\'' +
                '}';
    }
}
