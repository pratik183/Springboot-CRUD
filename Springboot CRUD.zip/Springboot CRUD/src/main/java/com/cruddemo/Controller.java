package com.cruddemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api") // Base URL for the controller
public class Controller {

    @Autowired
    private SchoolsService schoolsService;

    // Basic GET API
    @GetMapping("/hello")
    public String getHelloMessage() {
        return "Hello, World! Welcome to Spring Boot!";
    }

    @GetMapping("/getallschools")
    public List<Schools> getAllSchools() {
        return schoolsService.getAllSchools();
    }

    @PostMapping("/addschool")
    public Schools createSchool(@RequestBody Schools schools) {
        return schoolsService.createSchool(schools);
    }

    @GetMapping("/getschool/{id}")
    public ResponseEntity<Schools> getSchoolById(@PathVariable Long id){
        Schools schools= schoolsService.getSchoolById(id);

        if(schools != null){
            return ResponseEntity.ok(schools);
        }
        else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/removeschool/{id}")
    public ResponseEntity<Void> deleteSchool(@PathVariable Long id){
        schoolsService.deleteSchool(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/modifyschool/{id}")
    public ResponseEntity<Schools> modifySchool(@PathVariable Long id, @RequestBody Schools updatedSchool){
        Schools school=schoolsService.modifySchool(id,updatedSchool);
        if(school!=null) {
            return ResponseEntity.ok(school);
        }else{
            return ResponseEntity.notFound().build();
        }
    }
}
