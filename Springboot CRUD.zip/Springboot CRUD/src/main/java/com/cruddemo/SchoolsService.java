package com.cruddemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SchoolsService {

    @Autowired
    private SchoolsRepository schoolsRepository;

    public List<Schools> getAllSchools() {
        return schoolsRepository.findAll();
    }

    public Schools createSchool(Schools school) {
        return schoolsRepository.save(school);
    }

    public Schools getSchoolById(Long id) {
        return schoolsRepository.findById(id).orElse(null);
    }

    public void deleteSchool(Long id){
        schoolsRepository.deleteById(id);
    }


    public Schools modifySchool(Long id,Schools updatedSchool) {
        return schoolsRepository.findById(id).map(schools -> {
            schools.setSchoolName(updatedSchool.getSchoolName());
            schools.setSchoolEmail(updatedSchool.getSchoolEmail());
            return schoolsRepository.save(schools);
        }).orElse(null);
    }
}
